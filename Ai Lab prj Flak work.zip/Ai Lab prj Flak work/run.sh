#!/bin/bash

# Student Dropout Prediction App - Setup and Run Script
# This script sets up the environment and runs the Flask application

echo "=================================================="
echo "🎓 Student Dropout Prediction App - Setup"
echo "=================================================="
echo ""

# Check if Python 3 is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3.8 or higher."
    exit 1
fi

echo "✅ Python 3 found: $(python3 --version)"
echo ""

# Check if model file exists
if [ ! -f "model_svc.pkl" ]; then
    echo "⚠️  Warning: model_svc.pkl not found in current directory"
    echo "Please ensure the model file is present before running the app."
    exit 1
fi

echo "✅ Model file found: model_svc.pkl"
echo ""

# Install dependencies
echo "📦 Installing dependencies..."
pip3 install -r requirements.txt

if [ $? -eq 0 ]; then
    echo "✅ Dependencies installed successfully"
else
    echo "❌ Failed to install dependencies"
    exit 1
fi

echo ""
echo "=================================================="
echo "🚀 Starting Flask Application..."
echo "=================================================="
echo ""
echo "📍 The app will be available at: http://localhost:5000"
echo "🛑 Press Ctrl+C to stop the server"
echo ""

# Run the Flask app
python3 app.py
