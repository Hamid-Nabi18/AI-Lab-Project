# 🎓 Student Dropout Prediction Web Application

A beautiful, modern Flask web application that uses machine learning to predict student dropout risk. Built with a responsive UI featuring dark/light theme toggle, glassmorphism design, and smooth animations.

## ✨ Features

- **AI-Powered Predictions**: Uses a pre-trained SVM model to predict student dropout risk
- **Dynamic Form Generation**: Automatically detects and generates input fields for all 31 model features
- **Modern UI Design**: 
  - Glassmorphism/Neumorphism design
  - Dark/Light theme toggle with smooth transitions
  - Responsive layout (mobile, tablet, desktop)
  - Smooth animations and hover effects
- **Input Validation**: Real-time form validation with visual feedback
- **Beautiful Results Display**: Stylish prediction results with icons and animations
- **Bootstrap 5**: Fully responsive and mobile-friendly

## 📁 Project Structure

```
hamid flask/
│
├── app.py                  # Flask backend application
├── model_svc.pkl          # Pre-trained ML model (SVM)
├── requirements.txt       # Python dependencies
│
├── templates/
│   └── index.html         # Main HTML template with dynamic form
│
└── static/
    └── style.css          # Custom CSS with modern styling
```

## 🚀 Installation & Setup

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

### Step 1: Install Dependencies

Open a terminal and navigate to the project folder:

```bash
cd "/Users/laptop/Documents/hamid flask"
```

Install required Python packages:

```bash
pip install -r requirements.txt
```

### Step 2: Verify Model File

Make sure `model_svc.pkl` exists in the project root directory. The app will automatically load it on startup.

### Step 3: Run the Application

Start the Flask development server:

```bash
python app.py
```

You should see output like:
```
==================================================
🎓 Student Dropout Prediction App
==================================================
📊 Features loaded: 31
🤖 Model ready: True
==================================================

 * Running on http://0.0.0.0:5000
```

### Step 4: Access the Application

Open your web browser and navigate to:
```
http://localhost:5000
```

## 📊 Model Features

The model analyzes **31 different features** including:

- **Demographics**: Age, Gender, Marital status, Nationality
- **Academic Background**: Previous qualification, Mother's/Father's qualification & occupation
- **Enrollment Details**: Course, Application mode, Daytime/evening attendance
- **Financial Status**: Scholarship holder, Debtor, Tuition fees status
- **Academic Performance**: 
  - 1st Semester: Credits, enrollments, evaluations, grades
  - 2nd Semester: Credits, enrollments, evaluations, grades
- **Special Needs**: Educational special needs, Displaced status, International status

## 🎨 UI Features

### Theme Toggle
- Click the moon/sun icon in the navigation bar
- Switches between light and dark themes
- Theme preference is saved in browser localStorage

### Form Validation
- All input fields are required
- Real-time validation with visual feedback (green border for valid, red for invalid)
- Numeric validation with appropriate min/max ranges

### Prediction Results
- **Graduate**: Green success message with checkmark icon
- **Dropout**: Orange warning message with alert icon
- Smooth animations and centered display

## 🖥️ Usage Instructions

1. **Fill in the Form**: Enter values for all 31 student features
2. **Click "Predict Dropout Risk"**: The system will analyze the data
3. **View Results**: See the prediction result with a clear message
4. **Reset Form**: Click "Reset Form" to clear all inputs and start over

### Input Guidelines

- **Binary fields** (0 or 1): Gender, Debtor, Scholarship holder, etc.
- **Categorical fields** (1-50): Course, Qualification, Occupation codes
- **Grades** (0-20): Academic performance scores
- **Age** (17-70): Student age at enrollment
- **Academic units**: Number of credits, enrollments, evaluations

## 🔧 Customization

### Changing Prediction Labels

Edit `app.py`, lines 137-147 to customize prediction messages:

```python
if prediction_value == 0:
    result_text = "Graduate"
    message = "Your custom graduate message"
else:
    result_text = "Dropout"
    message = "Your custom dropout message"
```

### Styling Changes

Modify `static/style.css` to customize:
- Colors (`:root` variables)
- Animations
- Layout spacing
- Typography

### Adding More Features

If your model changes, the app automatically detects new features from the model's `feature_names_in_` attribute.

## 🐛 Troubleshooting

### Model Loading Error
```
Error: Model could not be loaded
```
**Solution**: Ensure `model_svc.pkl` is in the project root directory and is a valid scikit-learn model.

### Port Already in Use
```
Address already in use
```
**Solution**: Change the port in `app.py`:
```python
app.run(debug=True, host='0.0.0.0', port=5001)  # Changed from 5000
```

### Module Not Found Error
```
ModuleNotFoundError: No module named 'flask'
```
**Solution**: Install dependencies:
```bash
pip install -r requirements.txt
```

## 📱 Browser Compatibility

- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+
- ✅ Mobile browsers (iOS Safari, Chrome Mobile)

## 🔒 Security Notes

For production deployment:
1. Set `debug=False` in `app.py`
2. Use a production WSGI server (e.g., Gunicorn)
3. Add CSRF protection
4. Implement proper error handling
5. Use environment variables for configuration

## 📝 API Endpoints

- `GET /` - Main page with prediction form
- `POST /predict` - Prediction endpoint (accepts JSON)
- `GET /features` - Returns model feature information

### Example API Request

```bash
curl -X POST http://localhost:5000/predict \
  -H "Content-Type: application/json" \
  -d '{"Marital status": 1, "Application mode": 1, ...}'
```

## 👨‍💻 Development

To run in development mode with auto-reload:
```bash
export FLASK_ENV=development
python app.py
```

## 📄 License

This project is created for educational purposes.

## 🤝 Support

For issues or questions:
1. Check the troubleshooting section
2. Verify all dependencies are installed
3. Ensure Python 3.8+ is being used

---

**Built with ❤️ using Flask, Bootstrap 5, and Machine Learning**
