# Sample Test Data for Student Dropout Prediction App

This file contains sample student data that you can use to test the prediction system.

## Test Case 1: Low Risk Student (Expected: Graduate)
```
Marital status: 1
Application mode: 1
Application order: 0
Course: 33
Daytime/evening attendance: 1
Previous qualification: 1
Nacionality: 1
Mother's qualification: 37
Father's qualification: 37
Mother's occupation: 2
Father's occupation: 2
Displaced: 1
Educational special needs: 0
Debtor: 0
Tuition fees up to date: 1
Gender: 1
Scholarship holder: 0
Age at enrollment: 20
International: 0
Curricular units 1st sem (credited): 0
Curricular units 1st sem (enrolled): 6
Curricular units 1st sem (evaluations): 6
Curricular units 1st sem (approved): 6
Curricular units 1st sem (grade): 14.5
Curricular units 1st sem (without evaluations): 0
Curricular units 2nd sem (credited): 0
Curricular units 2nd sem (enrolled): 6
Curricular units 2nd sem (evaluations): 6
Curricular units 2nd sem (approved): 6
Curricular units 2nd sem (grade): 15.2
Curricular units 2nd sem (without evaluations): 0
```

## Test Case 2: High Risk Student (Expected: Dropout)
```
Marital status: 1
Application mode: 15
Application order: 5
Course: 171
Daytime/evening attendance: 1
Previous qualification: 1
Nacionality: 1
Mother's qualification: 1
Father's qualification: 1
Mother's occupation: 5
Father's occupation: 5
Displaced: 0
Educational special needs: 0
Debtor: 1
Tuition fees up to date: 0
Gender: 0
Scholarship holder: 0
Age at enrollment: 25
International: 0
Curricular units 1st sem (credited): 0
Curricular units 1st sem (enrolled): 5
Curricular units 1st sem (evaluations): 8
Curricular units 1st sem (approved): 2
Curricular units 1st sem (grade): 9.5
Curricular units 1st sem (without evaluations): 2
Curricular units 2nd sem (credited): 0
Curricular units 2nd sem (enrolled): 4
Curricular units 2nd sem (evaluations): 5
Curricular units 2nd sem (approved): 1
Curricular units 2nd sem (grade): 8.2
Curricular units 2nd sem (without evaluations): 1
```

## Test Case 3: Average Student (Results may vary)
```
Marital status: 1
Application mode: 8
Application order: 1
Course: 9500
Daytime/evening attendance: 1
Previous qualification: 1
Nacionality: 1
Mother's qualification: 19
Father's qualification: 13
Mother's occupation: 10
Father's occupation: 10
Displaced: 1
Educational special needs: 0
Debtor: 0
Tuition fees up to date: 1
Gender: 0
Scholarship holder: 1
Age at enrollment: 22
International: 0
Curricular units 1st sem (credited): 0
Curricular units 1st sem (enrolled): 6
Curricular units 1st sem (evaluations): 7
Curricular units 1st sem (approved): 4
Curricular units 1st sem (grade): 12.0
Curricular units 1st sem (without evaluations): 1
Curricular units 2nd sem (credited): 0
Curricular units 2nd sem (enrolled): 6
Curricular units 2nd sem (evaluations): 6
Curricular units 2nd sem (approved): 5
Curricular units 2nd sem (grade): 13.5
Curricular units 2nd sem (without evaluations): 0
```

## Feature Explanations

### Demographic Features
- **Marital status**: 1 (single), 2 (married), 3 (widower), 4 (divorced), 5 (facto union), 6 (legally separated)
- **Gender**: 0 (female), 1 (male)
- **Age at enrollment**: Student's age when enrolling (typically 17-70)
- **Nacionality**: Country code
- **International**: 0 (no), 1 (yes)

### Academic Background
- **Previous qualification**: Code for previous education level
- **Mother's qualification**: Code for mother's education level
- **Father's qualification**: Code for father's education level

### Application Details
- **Application mode**: How the student applied (1-18, different application routes)
- **Application order**: Order of preference for this course (0-9)
- **Course**: Course code

### Financial Status
- **Scholarship holder**: 0 (no), 1 (yes)
- **Debtor**: 0 (no), 1 (yes)
- **Tuition fees up to date**: 0 (no), 1 (yes)

### Occupations
- **Mother's occupation**: Code for mother's job
- **Father's occupation**: Code for father's job

### Special Circumstances
- **Displaced**: 0 (no), 1 (yes)
- **Educational special needs**: 0 (no), 1 (yes)
- **Daytime/evening attendance**: 1 (daytime), 0 (evening)

### Academic Performance (per semester)
- **Credited**: Number of units credited
- **Enrolled**: Number of units enrolled
- **Evaluations**: Number of evaluations taken
- **Approved**: Number of units passed
- **Grade**: Average grade (0-20 scale)
- **Without evaluations**: Number of units without evaluation

## Tips for Testing

1. **Good Academic Performance**: Higher grades (>13), more approved units, fewer evaluations without passing
2. **Financial Stability**: No debt, tuition up to date, scholarship can help
3. **Age Factor**: Very young (<18) or older (>30) students might have different risk profiles
4. **Parental Education**: Higher parental education levels often correlate with success
5. **Attendance**: Daytime attendance often shows better outcomes

## Using cURL to Test API

```bash
curl -X POST http://127.0.0.1:5001/predict \
  -H "Content-Type: application/json" \
  -d '{
    "Marital status": 1,
    "Application mode": 1,
    "Application order": 0,
    "Course": 33,
    "Daytime/evening attendance": 1,
    "Previous qualification": 1,
    "Nacionality": 1,
    "Mother'\''s qualification": 37,
    "Father'\''s qualification": 37,
    "Mother'\''s occupation": 2,
    "Father'\''s occupation": 2,
    "Displaced": 1,
    "Educational special needs": 0,
    "Debtor": 0,
    "Tuition fees up to date": 1,
    "Gender": 1,
    "Scholarship holder": 0,
    "Age at enrollment": 20,
    "International": 0,
    "Curricular units 1st sem (credited)": 0,
    "Curricular units 1st sem (enrolled)": 6,
    "Curricular units 1st sem (evaluations)": 6,
    "Curricular units 1st sem (approved)": 6,
    "Curricular units 1st sem (grade)": 14.5,
    "Curricular units 1st sem (without evaluations)": 0,
    "Curricular units 2nd sem (credited)": 0,
    "Curricular units 2nd sem (enrolled)": 6,
    "Curricular units 2nd sem (evaluations)": 6,
    "Curricular units 2nd sem (approved)": 6,
    "Curricular units 2nd sem (grade)": 15.2,
    "Curricular units 2nd sem (without evaluations)": 0
  }'
```
