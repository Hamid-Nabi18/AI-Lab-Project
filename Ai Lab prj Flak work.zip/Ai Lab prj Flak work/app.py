"""
Student Dropout Prediction Flask Application
==============================================
This Flask app loads a pre-trained machine learning model and provides
a web interface for predicting student dropout risk.
"""

from flask import Flask, render_template, request, jsonify
import pickle
import numpy as np
import os

# Initialize Flask application
app = Flask(__name__)

# Load the pre-trained machine learning model
MODEL_PATH = 'model_svc.pkl'

try:
    with open(MODEL_PATH, 'rb') as model_file:
        model = pickle.load(model_file)
    print("✓ Model loaded successfully!")
    print(f"✓ Model type: {type(model)}")
    print(f"✓ Number of features: {model.n_features_in_}")
except Exception as e:
    print(f"✗ Error loading model: {e}")
    model = None

# Extract feature names from the model
def get_feature_names():
    """
    Extracts feature names from the loaded model.
    Returns a list of feature names that the model expects.
    """
    if model and hasattr(model, 'feature_names_in_'):
        return model.feature_names_in_.tolist()
    return []

# Get feature information with descriptions
def get_feature_info():
    """
    Returns detailed information about each feature including
    name, type, and helpful descriptions for the UI.
    """
    feature_names = get_feature_names()
    
    # Define feature types and ranges for better UI generation
    feature_info = []
    
    for feature in feature_names:
        info = {
            'name': feature,
            'type': 'number',  # default type
            'min': 0,
            'max': 100,
            'step': 1,
            'placeholder': f'Enter {feature}'
        }
        
        # Customize based on feature name patterns
        if 'grade' in feature.lower():
            info['min'] = 0
            info['max'] = 20
            info['step'] = 0.1
            info['placeholder'] = 'Grade (0-20)'
        elif 'age' in feature.lower():
            info['min'] = 17
            info['max'] = 70
            info['step'] = 1
            info['placeholder'] = 'Age'
        elif any(x in feature.lower() for x in ['status', 'mode', 'qualification', 'occupation', 'course', 'nacionality']):
            info['min'] = 1
            info['max'] = 50
            info['step'] = 1
            info['placeholder'] = f'Code for {feature}'
        elif any(x in feature.lower() for x in ['gender', 'debtor', 'displaced', 'international', 'scholarship']):
            info['min'] = 0
            info['max'] = 1
            info['step'] = 1
            info['placeholder'] = '0 or 1'
        
        feature_info.append(info)
    
    return feature_info


@app.route('/')
def home():
    """
    Home route - renders the main page with the prediction form.
    Passes feature information to the template for dynamic form generation.
    """
    if model is None:
        return "Error: Model could not be loaded. Please check model_svc.pkl file.", 500
    
    features = get_feature_info()
    return render_template('index.html', features=features)


@app.route('/predict', methods=['POST'])
def predict():
    """
    Prediction route - receives form data, processes it, and returns prediction.
    
    Process:
    1. Extract form data (JSON format)
    2. Validate input data
    3. Convert to numpy array
    4. Make prediction using the model
    5. Return prediction result as JSON
    """
    try:
        # Get JSON data from the request
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data received'
            }), 400
        
        # Extract feature values in the correct order
        feature_names = get_feature_names()
        input_values = []
        
        for feature in feature_names:
            if feature not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing feature: {feature}'
                }), 400
            
            try:
                # Convert to float and validate
                value = float(data[feature])
                input_values.append(value)
            except ValueError:
                return jsonify({
                    'success': False,
                    'error': f'Invalid value for {feature}. Must be a number.'
                }), 400
        
        # Convert to numpy array with the correct shape (1, n_features)
        input_array = np.array(input_values).reshape(1, -1)
        
        # Validate array shape
        if input_array.shape[1] != model.n_features_in_:
            return jsonify({
                'success': False,
                'error': f'Expected {model.n_features_in_} features, got {input_array.shape[1]}'
            }), 400
        
        # Make prediction
        prediction = model.predict(input_array)
        
        # Get prediction probability if available
        prediction_proba = None
        if hasattr(model, 'predict_proba'):
            try:
                proba = model.predict_proba(input_array)
                prediction_proba = proba[0].tolist()
            except:
                pass
        
        # Interpret prediction result
        # Handle both numeric and string predictions
        prediction_raw = prediction[0]
        
        # Convert prediction to string for comparison
        prediction_str = str(prediction_raw)
        
        # Determine if it's a dropout or graduate prediction
        # Check for various possible formats: "Dropout", "dropout", 1, "1", etc.
        is_dropout = prediction_str.lower() in ['dropout', '1', '1.0'] or prediction_raw == 1
        
        if is_dropout:
            result_text = "Dropout"
            result_class = "warning"
            message = "The student is at risk of dropping out. Consider intervention measures. ⚠️"
            prediction_value = 1
        else:
            result_text = "Graduate"
            result_class = "success"
            message = "The student is predicted to successfully complete the program! 🎓"
            prediction_value = 0
        
        # Return successful prediction
        return jsonify({
            'success': True,
            'prediction': result_text,
            'prediction_value': prediction_value,
            'result_class': result_class,
            'message': message,
            'probability': prediction_proba
        })
    
    except Exception as e:
        # Handle any unexpected errors
        print(f"Prediction error: {e}")
        return jsonify({
            'success': False,
            'error': f'Prediction failed: {str(e)}'
        }), 500


@app.route('/features')
def features():
    """
    API endpoint to get feature information.
    Useful for debugging or dynamic form generation.
    """
    return jsonify({
        'features': get_feature_info(),
        'count': len(get_feature_names())
    })


# Error handlers
@app.errorhandler(404)
def not_found(e):
    """Handle 404 errors"""
    return render_template('index.html', features=get_feature_info()), 404


@app.errorhandler(500)
def server_error(e):
    """Handle 500 errors"""
    return "Internal Server Error", 500


# Run the Flask application
if __name__ == '__main__':
    print("\n" + "="*50)
    print("🎓 Student Dropout Prediction App")
    print("="*50)
    print(f"📊 Features loaded: {len(get_feature_names())}")
    print(f"🤖 Model ready: {model is not None}")
    print("="*50 + "\n")
    
    # Run the app in debug mode
    # For production, set debug=False
    app.run(debug=True, host='0.0.0.0', port=5001)
